<footer class="pied__page">
    <h3>le pied de page</h3>
</footer>

<?php 
 wp_footer();
?>