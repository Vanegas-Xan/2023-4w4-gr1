<?php
/**
 * Modèle par défaut
 * 
 */
?>
<?php get_header(); ?>
<main>
<h3>404.php</h3>
<h1>Page non disponible</h1>
</main>

<?php get_footer(); ?>