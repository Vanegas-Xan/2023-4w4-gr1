# TP1
## 4w4-Création d'interface et développement web
### Auteur : Xander Vanegas

#### Objectifs: 
-  Le design général permettre de mettre en valeur le programme TIM du colll`ge de Maisonneuve
-  Continuer de faire progrésser le thème
-  Déployer le projet sur siteground


##### Lien de référence
- Site sur le serveur distant 
https://cidweb43.sg-host.com/