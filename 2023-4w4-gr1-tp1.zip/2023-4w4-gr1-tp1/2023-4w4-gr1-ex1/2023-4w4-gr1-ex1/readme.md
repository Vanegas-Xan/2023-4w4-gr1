# lab1
## 4w4-Création d'interface et développement web
### Auteur : Xander Vanegas
#### Description : 
- Installation de Wordpress
- Création d'un premier thème
- Création d'un dépôt git