### voici une liste de site inspirant

https://www.scrum.org/
